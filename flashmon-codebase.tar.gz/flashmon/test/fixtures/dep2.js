export default "dep2";
