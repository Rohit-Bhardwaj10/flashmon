import "./dep1.js";
import "./dep2.js";
