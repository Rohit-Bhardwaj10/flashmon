// import path from "path";
// import fs from "fs";
//
// export function resolvePath(importPath: string, parentFile: string): string {
//   console.log("resolvePath:", importPath, parentFile);
//   // Only handle relative or absolute imports
//   if (importPath.startsWith(".") || importPath.startsWith("/")) {
//     // This is the correct parent directory!
//     const parentDir = path.dirname(parentFile);
//     let resolved = path.resolve(parentDir, importPath);
//
//     // Check if the path exists as-is
//     if (fs.existsSync(resolved) && fs.statSync(resolved).isFile()) {
//       return resolved;
//     }
//
//     // Try appending common extensions
//     const exts = [".js", ".ts", ".jsx", ".tsx", ".json"];
//     for (const ext of exts) {
//       if (fs.existsSync(resolved + ext)) {
//         return resolved + ext;
//       }
//     }
//
//     // Try index files in directories
//     for (const ext of exts) {
//       const indexPath = path.join(resolved, `index${ext}`);
//       if (fs.existsSync(indexPath)) {
//         return indexPath;
//       }
//     }
//
//     throw new Error(
//       `Cannot resolve import path: ${importPath} from ${parentFile}`
//     );
//   } else {
//     throw new Error(
//       `Non-relative imports (e.g., packages) are not supported: ${importPath}`
//     );
//   }
// }
import path from "path";
import fs from "fs";

/**
 * Resolves an import path relative to the parent file.
 * Handles:
 *   - './feature/greet.js'
 *   - '../utils.js'
 *   - '/absolute/path.js' (from project root, optional)
 *   - Adds .js, .ts, .jsx, .tsx, .json extensions if missing.
 */
export function resolvePath(
  importPath: string,
  parentFile: string,
  projectRoot?: string
): string {
  console.log("resolvePath:", importPath, parentFile);

  let resolved: string;

  // Handle relative imports
  if (importPath.startsWith(".")) {
    const parentDir = path.dirname(parentFile);
    resolved = path.resolve(parentDir, importPath);
  }
  // Handle absolute imports from project root (optional)
  else if (importPath.startsWith("/")) {
    if (!projectRoot) {
      throw new Error("Project root must be specified for absolute imports.");
    }
    resolved = path.join(projectRoot, importPath);
  }
  // Bare imports (e.g., packages)
  else {
    throw new Error(
      `Non-relative imports (e.g., packages) are not supported: ${importPath}`
    );
  }

  // Check if the path exists as-is
  if (fs.existsSync(resolved) && fs.statSync(resolved).isFile()) {
    return resolved;
  }

  // Try appending common extensions
  const exts = [".js", ".ts", ".jsx", ".tsx", ".json"];
  for (const ext of exts) {
    if (fs.existsSync(resolved + ext)) {
      return resolved + ext;
    }
  }

  // Try index files in directories
  for (const ext of exts) {
    const indexPath = path.join(resolved, `index${ext}`);
    if (fs.existsSync(indexPath)) {
      return indexPath;
    }
  }

  console.error(`Failed to resolve import: ${importPath} from ${parentFile}`);
  throw new Error(
    `Cannot resolve import path: ${importPath} from ${parentFile}`
  );
}
